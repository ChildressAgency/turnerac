# acf-signature
A signature field for Advanced Custom Fields v4, v5 and up...

Based on work done by http://Jupitercow.com/ for v4, I've adpated the code and javascript for use in Advanced Custom Fields v5 and Pro.
